<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.pendaftar.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.pendaftars.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="no_tiket"><?php echo e(trans('cruds.pendaftar.fields.no_tiket')); ?></label>
                <input class="form-control <?php echo e($errors->has('no_tiket') ? 'is-invalid' : ''); ?>" type="text" name="no_tiket" id="no_tiket" value="<?php echo e(0 . $no_t->no_tiket+1); ?>" disabled>
                <?php if($errors->has('no_tiket')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('no_tiket')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.no_tiket_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="nama"><?php echo e(trans('cruds.pendaftar.fields.nama')); ?></label>
                <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama" id="nama" value="<?php echo e(old('nama', '')); ?>" required>
                <?php if($errors->has('nama')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.nama_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="nik"><?php echo e(trans('cruds.pendaftar.fields.nik')); ?></label>
                <input class="form-control <?php echo e($errors->has('nik') ? 'is-invalid' : ''); ?>" type="text" name="nik" id="nik" value="<?php echo e(old('nik', '')); ?>" required>
                <?php if($errors->has('nik')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nik')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.nik_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="email"><?php echo e(trans('cruds.pendaftar.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="text" name="email" id="email" value="<?php echo e(old('email', '')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="no_hp"><?php echo e(trans('cruds.pendaftar.fields.no_hp')); ?></label>
                <input class="form-control <?php echo e($errors->has('no_hp') ? 'is-invalid' : ''); ?>" type="text" name="no_hp" id="no_hp" value="<?php echo e(old('no_hp', '')); ?>" required>
                <?php if($errors->has('no_hp')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('no_hp')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.no_hp_helper')); ?></span>
            </div>
            
            <div class="form-group">
                <label for="notes"><?php echo e(trans('cruds.pendaftar.fields.notes')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"><?php echo old('notes'); ?></textarea>
                <?php if($errors->has('notes')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('notes')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.notes_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.pendaftar.fields.status_payment')); ?></label>
                <select class="form-control <?php echo e($errors->has('status_payment') ? 'is-invalid' : ''); ?>" name="status_payment" id="status_payment">
                    <option value disabled <?php echo e(old('status_payment', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Pendaftar::STATUS_PAYMENT_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status_payment', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status_payment')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status_payment')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.status_payment_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="event_id"><?php echo e(trans('cruds.pendaftar.fields.event')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('event') ? 'is-invalid' : ''); ?>" name="event_id" id="event_id">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('event_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('event')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('event')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.event_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.pendaftar.fields.payment_type')); ?></label>
                <select class="form-control <?php echo e($errors->has('payment_type') ? 'is-invalid' : ''); ?>" name="payment_type" id="payment_type">
                    <option value disabled <?php echo e(old('payment_type', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Pendaftar::PAYMENT_TYPE_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('payment_type', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('payment_type')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('payment_type')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.payment_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="total_bayar"><?php echo e(trans('cruds.pendaftar.fields.total_bayar')); ?></label>
                <input class="form-control <?php echo e($errors->has('total_bayar') ? 'is-invalid' : ''); ?>" type="text" name="total_bayar" id="total_bayar" value="<?php echo e(old('total_bayar', '')); ?>">
                <?php if($errors->has('total_bayar')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('total_bayar')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.total_bayar_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.pendaftars.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($pendaftar->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forkomdi/event.kardusinfo.com/resources/views/admin/pendaftars/create.blade.php ENDPATH**/ ?>