<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.pendaftar.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.pendaftars.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.no_tiket')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->no_tiket); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.nama')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->nama); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.nik')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->nik); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.email')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->email); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.no_hp')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->no_hp); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.checkin')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Pendaftar::CHECKIN_SELECT[$pendaftar->checkin] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.notes')); ?>

                        </th>
                        <td>
                            <?php echo $pendaftar->notes; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.status_payment')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Pendaftar::STATUS_PAYMENT_SELECT[$pendaftar->status_payment] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.event')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->event->nama_event ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.payment_type')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Pendaftar::PAYMENT_TYPE_SELECT[$pendaftar->payment_type] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.pendaftar.fields.total_bayar')); ?>

                        </th>
                        <td>
                            <?php echo e($pendaftar->total_bayar); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.pendaftars.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forkomdi/event.kardusinfo.com/resources/views/admin/pendaftars/show.blade.php ENDPATH**/ ?>