<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.transaksi.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.transaksis.update", [$transaksi->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="invoice"><?php echo e(trans('cruds.transaksi.fields.invoice')); ?></label>
                <input class="form-control <?php echo e($errors->has('invoice') ? 'is-invalid' : ''); ?>" type="text" name="invoice" id="invoice" value="<?php echo e(old('invoice', $transaksi->invoice)); ?>">
                <?php if($errors->has('invoice')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('invoice')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.invoice_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="event_id"><?php echo e(trans('cruds.transaksi.fields.event')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('event') ? 'is-invalid' : ''); ?>" name="event_id" id="event_id">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('event_id') ? old('event_id') : $transaksi->event->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('event')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('event')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.event_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tiket_id"><?php echo e(trans('cruds.transaksi.fields.tiket')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('tiket') ? 'is-invalid' : ''); ?>" name="tiket_id" id="tiket_id">
                    <?php $__currentLoopData = $tikets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('tiket_id') ? old('tiket_id') : $transaksi->tiket->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('tiket')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tiket')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.tiket_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="peserta_id"><?php echo e(trans('cruds.transaksi.fields.peserta')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('peserta') ? 'is-invalid' : ''); ?>" name="peserta_id" id="peserta_id">
                    <?php $__currentLoopData = $pesertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('peserta_id') ? old('peserta_id') : $transaksi->peserta->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('peserta')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('peserta')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.peserta_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="amount"><?php echo e(trans('cruds.transaksi.fields.amount')); ?></label>
                <input class="form-control <?php echo e($errors->has('amount') ? 'is-invalid' : ''); ?>" type="text" name="amount" id="amount" value="<?php echo e(old('amount', $transaksi->amount)); ?>">
                <?php if($errors->has('amount')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('amount')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.amount_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="note"><?php echo e(trans('cruds.transaksi.fields.note')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('note') ? 'is-invalid' : ''); ?>" name="note" id="note"><?php echo old('note', $transaksi->note); ?></textarea>
                <?php if($errors->has('note')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('note')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.note_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="snap_token"><?php echo e(trans('cruds.transaksi.fields.snap_token')); ?></label>
                <input class="form-control <?php echo e($errors->has('snap_token') ? 'is-invalid' : ''); ?>" type="text" name="snap_token" id="snap_token" value="<?php echo e(old('snap_token', $transaksi->snap_token)); ?>">
                <?php if($errors->has('snap_token')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('snap_token')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.snap_token_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.transaksi.fields.status')); ?></label>
                <select class="form-control <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status" id="status">
                    <option value disabled <?php echo e(old('status', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Transaksi::STATUS_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('status', $transaksi->status) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.transaksi.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('admin.transaksis.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($transaksi->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forkomdi/event.kardusinfo.com/resources/views/admin/transaksis/edit.blade.php ENDPATH**/ ?>