<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.event.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.events.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nama_event"><?php echo e(trans('cruds.event.fields.nama_event')); ?></label>
                <input class="form-control <?php echo e($errors->has('nama_event') ? 'is-invalid' : ''); ?>" type="text" name="nama_event" id="nama_event" value="<?php echo e(old('nama_event', '')); ?>">
                <?php if($errors->has('nama_event')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama_event')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.nama_event_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="event_code"><?php echo e(trans('cruds.event.fields.event_code')); ?></label>
                <input class="form-control <?php echo e($errors->has('event_code') ? 'is-invalid' : ''); ?>" type="text" name="event_code" id="event_code" value="<?php echo e(old('event_code', '')); ?>">
                <?php if($errors->has('event_code')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('event_code')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.event_code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="harga"><?php echo e(trans('cruds.event.fields.harga')); ?></label>
                <input class="form-control <?php echo e($errors->has('harga') ? 'is-invalid' : ''); ?>" type="text" name="harga" id="harga" value="<?php echo e(old('harga', '')); ?>">
                <?php if($errors->has('harga')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('harga')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.harga_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tanggal_mulai"><?php echo e(trans('cruds.event.fields.tanggal_mulai')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('tanggal_mulai') ? 'is-invalid' : ''); ?>" type="text" name="tanggal_mulai" id="tanggal_mulai" value="<?php echo e(old('tanggal_mulai')); ?>">
                <?php if($errors->has('tanggal_mulai')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tanggal_mulai')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.tanggal_mulai_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tanggal_selesai"><?php echo e(trans('cruds.event.fields.tanggal_selesai')); ?></label>
                <input class="form-control datetime <?php echo e($errors->has('tanggal_selesai') ? 'is-invalid' : ''); ?>" type="text" name="tanggal_selesai" id="tanggal_selesai" value="<?php echo e(old('tanggal_selesai')); ?>">
                <?php if($errors->has('tanggal_selesai')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tanggal_selesai')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.event.fields.tanggal_selesai_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forkomdi/event.kardusinfo.com/resources/views/admin/events/create.blade.php ENDPATH**/ ?>