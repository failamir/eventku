<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.tiket.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.tikets.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($tiket->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.no_tiket')); ?>

                        </th>
                        <td>
                            <?php echo e($tiket->no_tiket); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.peserta')); ?>

                        </th>
                        <td>
                            <?php echo e($tiket->peserta->email ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.checkin')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Tiket::CHECKIN_SELECT[$tiket->checkin] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.notes')); ?>

                        </th>
                        <td>
                            <?php echo $tiket->notes; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.status_payment')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Tiket::STATUS_PAYMENT_SELECT[$tiket->status_payment] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.payment_type')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Tiket::PAYMENT_TYPE_SELECT[$tiket->payment_type] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.total_bayar')); ?>

                        </th>
                        <td>
                            <?php echo e($tiket->total_bayar); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.tiket.fields.qr')); ?>

                        </th>
                        <td>
                            <?php if($tiket->qr): ?>
                                <a href="<?php echo e($tiket->qr->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($tiket->qr->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.tikets.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link" href="#tiket_transaksis" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.transaksi.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="tiket_transaksis">
            <?php if ($__env->exists('admin.tikets.relationships.tiketTransaksis', ['transaksis' => $tiket->tiketTransaksis])) echo $__env->make('admin.tikets.relationships.tiketTransaksis', ['transaksis' => $tiket->tiketTransaksis], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forkomdi/event.kardusinfo.com/resources/views/admin/tikets/show.blade.php ENDPATH**/ ?>