<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <div class="card">
                <div class="card-header">
                    Isi Data Diri
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route("bayar")); ?>" enctype="multipart/form-data">
                        <?php echo method_field('POST'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="no_tiket"><?php echo e(trans('cruds.pendaftar.fields.no_tiket')); ?></label>
                            <input class="form-control <?php echo e($errors->has('no_tiket') ? 'is-invalid' : ''); ?>" type="text" name="no_tiket" id="no_tiket" value="<?php echo e(0 . $no_t->no_tiket+1); ?>" disabled>
                            <?php if($errors->has('no_tiket')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('no_tiket')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.no_tiket_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="nama"><?php echo e(trans('cruds.pendaftar.fields.nama')); ?></label>
                            <input class="form-control" type="text" name="nama" id="nama" value="<?php echo e(old('nama', '')); ?>" required>
                            <?php if($errors->has('nama')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('nama')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.nama_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="nik"><?php echo e(trans('cruds.pendaftar.fields.nik')); ?></label>
                            <input class="form-control" type="text" name="nik" id="nik" value="<?php echo e(old('nik', '')); ?>" required>
                            <?php if($errors->has('nik')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('nik')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.nik_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="email"><?php echo e(trans('cruds.pendaftar.fields.email')); ?></label>
                            <input class="form-control" type="text" name="email" id="email" value="<?php echo e(old('email', '')); ?>" required>
                            <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('email')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.email_helper')); ?></span>
                        </div>
                        <div class="form-group">
                            <label class="required" for="no_hp"><?php echo e(trans('cruds.pendaftar.fields.no_hp')); ?></label>
                            <input class="form-control" type="text" name="no_hp" id="no_hp" value="<?php echo e(old('no_hp', '')); ?>" required>
                            <?php if($errors->has('no_hp')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('no_hp')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.no_hp_helper')); ?></span>
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="total_bayar"><?php echo e(trans('cruds.pendaftar.fields.total_bayar')); ?></label>
                            
                            
                            <p>
                                _________________________________________________
                            </p>

                            <?php if($data['day_1'] > 0): ?>
                            <?php echo e($data['day_1']); ?> Ticket Day 1  -->  Rp. <?php echo e($data['price_1']); ?><br>
                            <input type="hidden" name="day_1" value="<?php echo e($data['day_1']); ?>">
                            <br>
                            <?php endif; ?>

                            <?php if($data['day_2'] > 0): ?>
                            <?php echo e($data['day_2']); ?> Ticket Day 2  -->  Rp. <?php echo e($data['price_2']); ?><br>
                            <input type="hidden" name="day_2" value="<?php echo e($data['day_2']); ?>">
                            <br>
                            <?php endif; ?>

                            <?php if($data['day_3'] > 0): ?>
                            <?php echo e($data['day_3']); ?> Ticket Day 1 & 2  --> Rp. <?php echo e($data['price_3']); ?><br>
                            <input type="hidden" name="day_3" value="<?php echo e($data['day_3']); ?>">
                            <br>
                            <?php endif; ?>

                            


                            <input class="form-control" type="hidden" name="total_bayar" id="total_bayar" value="<?php echo e(old('total_bayar', '')); ?>">
                            <?php if($errors->has('total_bayar')): ?>
                                <div class="invalid-feedback">
                                    <?php echo e($errors->first('total_bayar')); ?>

                                </div>
                            <?php endif; ?>
                            <span class="help-block"><?php echo e(trans('cruds.pendaftar.fields.total_bayar_helper')); ?></span>
                        </div>
                        <div class="form-group text-center ">
                            <button class="btn btn-danger" type="submit">
                                
                                Bayar Sekarang
                            </button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '<?php echo e(route('frontend.pendaftars.storeCKEditorImages')); ?>', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($pendaftar->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/forkomdi/event.kardusinfo.com/resources/views/daftar.blade.php ENDPATH**/ ?>